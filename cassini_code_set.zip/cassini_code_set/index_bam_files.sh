#!/bin/bash

# Directory containing BAM files
BAM_DIR="/broad/macosko/Nicolas/star_alignment_16nt"

# Loop through all BAM files in the directory
for bam_file in "$BAM_DIR"/*.bam; do
    # Check if there are any BAM files in the directory
    if [ ! -f "$bam_file" ]; then
        echo "No BAM files found in $BAM_DIR."
        exit 1
    fi

    echo "Indexing $bam_file..."
    
    # Run samtools index on the current BAM file
    samtools index "$bam_file"
    
    echo "Indexing completed for $bam_file."
done

echo "All BAM files have been indexed!"