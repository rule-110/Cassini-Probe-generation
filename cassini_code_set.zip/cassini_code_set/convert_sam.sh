#!/bin/bash

# Directory containing BAM files
BAM_DIR="/broad/macosko/Nicolas/star_exon_16nt_human"

# Directory to store SAM files
SAM_DIR="$BAM_DIR/sam_16nt_human_exon"

# Create SAM directory if it doesn't exist
mkdir -p "$SAM_DIR"

# Loop through all BAM files in the directory
for bam_file in "$BAM_DIR"/*.bam; do
    # Check if there are any BAM files in the directory
    if [ ! -f "$bam_file" ]; then
        echo "No BAM files found in $BAM_DIR."
        exit 1
    fi

    # Get the base name of the BAM file
    bam_basename=$(basename "$bam_file" .bam)

    echo "Processing $bam_file..."

    # Convert BAM to SAM and save in the same directory
    sam_file="$BAM_DIR/${bam_basename}.sam"
    samtools view -h "$bam_file" > "$sam_file"

    echo "Conversion completed for $bam_file. Output saved to $sam_file."

    # Move the generated SAM file to the SAM directory
    mv "$sam_file" "$SAM_DIR/"
done

echo "All BAM files have been processed and SAM files have been moved to $SAM_DIR!"
