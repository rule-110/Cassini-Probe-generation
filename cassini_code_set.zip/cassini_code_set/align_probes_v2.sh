#!/bin/bash

# Parent input directory containing subdirectories with FASTA files
PARENT_INPUT_DIR="/broad/macosko/Nicolas/bulk_prealignment"
# Directory for STAR genome index
GENOME_DIR="/broad/macosko/Nicolas/marmoset_genome"
# Parent output directory for alignment results
PARENT_OUTPUT_DIR="/broad/macosko/Nicolas/bulk_star"

# Create parent output directory if it doesn't exist
mkdir -p "$PARENT_OUTPUT_DIR"

# Loop through all subdirectories in the parent input directory
for sub_dir in "$PARENT_INPUT_DIR"/*/; do
    # Get the base name of the subdirectory
    sub_dir_name=$(basename "$sub_dir")
    
    # Define the output directory for the current subdirectory
    OUTPUT_DIR="$PARENT_OUTPUT_DIR/$sub_dir_name"
    mkdir -p "$OUTPUT_DIR"

    echo "Processing directory: $sub_dir"
    echo "Output directory: $OUTPUT_DIR"

    # Loop through all FASTA files in the current subdirectory
    for probe_file in "$sub_dir"/*.fasta; do
        # Check if there are no FASTA files in the current subdirectory
        if [ ! -f "$probe_file" ]; then
            echo "No FASTA files found in $sub_dir."
            continue
        fi

        # Get the base name of the file (without directory and extension)
        base_name=$(basename "$probe_file" .fasta)

        # Define the output prefix for STAR with "star" appended
        output_prefix="$OUTPUT_DIR/${base_name}_star_"

        echo "Processing $probe_file..."

        # Run STAR alignment for the current file
        STAR --runThreadN 12 \
             --genomeDir "$GENOME_DIR" \
             --readFilesIn "$probe_file" \
             --outFileNamePrefix "$output_prefix" \
             --outSAMtype BAM SortedByCoordinate \
             --outFilterMultimapNmax 10 \
             --winAnchorMultimapNmax 200 \
             --outSAMattributes NH HI NM MD AS nM \
             --outFilterMismatchNmax 16

        echo "Alignment for $probe_file completed. Output saved to $output_prefix"
    done

    echo "Completed processing for directory: $sub_dir"
done

echo "All alignments completed!"
