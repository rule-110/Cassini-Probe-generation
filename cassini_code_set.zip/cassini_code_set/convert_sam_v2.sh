#!/bin/bash

# Parent directory containing BAM files in subdirectories
PARENT_BAM_DIR="/broad/macosko/Nicolas/bulk_star"

# Parent directory to store SAM files
PARENT_SAM_DIR="/broad/macosko/Nicolas/bulk_sam"

# Create parent SAM directory if it doesn't exist
mkdir -p "$PARENT_SAM_DIR"

# Loop through all subdirectories in the parent BAM directory
for sub_dir in "$PARENT_BAM_DIR"/*/; do
    # Get the base name of the subdirectory
    sub_dir_name=$(basename "$sub_dir")

    # Define the SAM directory for the current subdirectory
    SAM_DIR="$PARENT_SAM_DIR/$sub_dir_name"
    mkdir -p "$SAM_DIR"

    echo "Processing directory: $sub_dir"
    echo "SAM files will be saved to: $SAM_DIR"

    # Loop through all BAM files in the current subdirectory
    for bam_file in "$sub_dir"/*.bam; do
        # Check if there are any BAM files in the current subdirectory
        if [ ! -f "$bam_file" ]; then
            echo "No BAM files found in $sub_dir."
            continue
        fi

        # Get the base name of the BAM file
        bam_basename=$(basename "$bam_file" .bam)

        echo "Processing $bam_file..."

        # Convert BAM to SAM and save in the SAM directory
        sam_file="$SAM_DIR/${bam_basename}.sam"
        samtools view -h "$bam_file" > "$sam_file"

        echo "Conversion completed for $bam_file. Output saved to $sam_file."
    done

    echo "Completed processing for directory: $sub_dir"
done

echo "All BAM files have been processed and SAM files have been saved!"
